from flask import Flask, request, render_template, redirect, url_for
import sqlite3
import pandas as pd
import yfinance as yf
from datetime import datetime
import statsmodels.tsa.stattools as ts 
from statsmodels.tsa.stattools import adfuller
import matplotlib.pyplot as plt
import seaborn as sn
from matplotlib.pyplot import figure
import numpy as np
from strategies import *
import jsonify
import json
from yfin import *

data=None

high_corr_pairs = []

app = Flask(__name__)

def save_data_to_db(data):
    conn = sqlite3.connect('/Users/yashedake/Desktop/Projects/backtesting/strategies.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS strategies (
            strategy_name TEXT,
            instrument_name TEXT,
            start_date TEXT,
            end_date TEXT,
            time_frame TEXT,
            expiry TEXT,
            strike TEXT,
            strike_length TEXT,
            option_type TEXT,
            lot_size TEXT,
            spread TEXT,
            stop_loss TEXT,
            book_profit TEXT,
            action TEXT
        )
    ''')

    cursor.execute('''
        INSERT INTO strategies (strategy_name, instrument_name, start_date, end_date, time_frame,expiry , strike, strike_length, option_type, lot_size,spread,exit_spread, action)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        data['strategy_name'],
        data['instrument_name'],
        data['start_date'],
        data['end_date'],
        data['time_frame'],
        data['expiry'],
        data['strike'],
        data['lot_size'],
        data['spread'],
        data['stop_loss'],
        data['book_profit'],
    ))
    try:
        conn.commit()
        print('Data saved to database successfully.')
    except Exception as e:
        print(f'Error saving data to database: {e}')
    
    conn.close()

nifty_50_tickers = [
    "ADANIPORTS", "ASIANPAINT", "AXISBANK", "BAJAJ-AUTO", "BAJFINANCE",
    "BAJAJFINSV", "BPCL", "BHARTIARTL", "BRITANNIA", "CIPLA", "COALINDIA",
    "DIVISLAB", "DRREDDY", "EICHERMOT", "GRASIM", "HCLTECH", "HDFCBANK",
    "HDFCLIFE", "HEROMOTOCO", "HINDALCO", "HINDUNILVR", "HDFC", "ICICIBANK",
    "ITC", "INDUSINDBK", "INFY", "JSWSTEEL", "KOTAKBANK", "LT", "M&M",
    "MARUTI", "NTPC", "NESTLEIND", "ONGC", "POWERGRID", "RELIANCE", "SBILIFE",
    "SBIN", "SUNPHARMA", "TCS", "TATACONSUM", "TATAMOTORS", "TATASTEEL",
    "TECHM", "TITAN", "ULTRACEMCO", "UPL", "WIPRO","^NSEI"
]

def get_historical_Data(tickers):
    """This function returns a pd dataframe with all of the adjusted closing information"""
    data = pd.DataFrame()
    names = list()
    for i in tickers:
        data = pd.concat([data, pd.DataFrame(yf.download(i + '.NS', start=datetime(2022, 5, 21), end=datetime(2024, 5, 21)).iloc[:, 4])], axis=1)
        names.append(i)
    data.columns = names
    return data

def calculate_returns(buy_prices, sell_prices):
    returns = sell_prices / buy_prices - 1
    return returns

def logs(data):
    excel_file_path = 'trades.xlsx'
    data.to_excel(excel_file_path)

def round_to_nearest_50(x):
    return round(x / 50) * 50

@app.route('/', methods=['GET', 'POST'])
def select():
    global data
    if request.method == 'POST':
        instrument_name = request.form.get('instrument_name').upper()
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')
        strategy_name = request.form.get('strategy_name')

        start_date = datetime.strptime(start_date, '%Y-%m-%d')
        end_date = datetime.strptime(end_date, '%Y-%m-%d')
        formatted_strategy_name = strategy_name.replace(' ', '_').lower()
        print(formatted_strategy_name)
        data=get_data(start_date, end_date, trading_start, trading_end, instrument_name, timeframe=360)
        data.dropna(subset=['Close'], inplace=True)
        data['Close'] = data['Close'].apply(round_to_nearest_50)
        print(data)
        

        return redirect(url_for(f'{formatted_strategy_name}'))


    return render_template('selectStrategy.html')

@app.route('/form')
def form():
    return render_template('form.html')


@app.route('/long_short_bull',methods=['GET', 'POST'])
def long_short_bull():
    
    global data

    print("hello")
    print(data)
    # strike_price_long = data['strike_price_long']  
    strike_price_long=25000
    strike_price_short=20000

    # strike_price_short = data['strike_price_short']  
    # premium_long = data['premium_long']  
    # premium_short = data['premium_short']  
    # expiration_date = data['expiration_date'] 

    strike_prices = [
        {'name': strike_price_long, 'label': 'Long'},
        {'name': strike_price_short, 'label': 'Short'},
        # Add more strike price objects as needed
    ] 
    
    
    return render_template('strategy.html', strike_prices=strike_prices)

@app.route('/iron_condor',methods=['GET', 'POST'])
def iron_condor():

    # strike_price_long = data['strike_price_long']  
    # lower_strike_put = option['lower_strike_put']
    # higher_strike_put = option['higher_strike_put']
    # lower_strike_call = option['lower_strike_call']
    # higher_strike_call = option['higher_strike_call']

    lower_strike_put=25000
    higher_strike_put=19000
    lower_strike_call=27000
    higher_strike_call=18000

    strike_prices = [
        {'name': lower_strike_put, 'label': 'Long'},
        {'name': higher_strike_put, 'label': 'Short'},
        {'name': lower_strike_call, 'label': 'Short'},
        {'name': higher_strike_call, 'label': 'Long'},

    ] 
    
    return render_template('strategy.html', strike_prices=strike_prices)

def backtest_rsi_strategy(ticker, start_date, end_date, lower_rsi, upper_rsi, time_frame):
    
    data = yf.download(ticker, start=start_date, end=end_date, interval=time_frame)
    
    delta = data['Close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    data['RSI'] = 100 - (100 / (1 + rs))
    
    data['Signal'] = 0
    data['Position'] = 0
    data['Buy Price'] = np.nan
    data['Sell Price'] = np.nan
    
    current_position = 0
    signals = []
    pnl=0

    for i in range(len(data)):
        if current_position == 0:
            if data['RSI'].iloc[i] < lower_rsi:
                # Enter long position
                current_position = 1
                entry_price = data['Close'].iloc[i]
                data.at[data.index[i], 'Signal'] = 1
                data.at[data.index[i], 'Buy Price'] = entry_price
                signals.append((data.index[i], 'BUY', entry_price))
        elif current_position == 1:
            if data['RSI'].iloc[i] > upper_rsi:
                current_position = 0
                exit_price = data['Close'].iloc[i]
                data.at[data.index[i], 'Signal'] = -1
                data.at[data.index[i], 'Sell Price'] = exit_price
                pnl=entry_price-exit_price
                signals.append((data.index[i], 'SELL', exit_price))

    signals.append((data.index[i], 'PNL', pnl))
    return signals

@app.route('/rsi', methods=['POST'])
def backtest_rsi():
    ticker = request.form['ticker']
    start_date = request.form['start_date']
    end_date = request.form['end_date']
    short_window = int(request.form['short_window'])
    long_window = int(request.form['long_window'])
    time_frame = request.form['time_frame']

    signals = backtest_rsi_strategy(ticker, start_date, end_date, short_window, long_window, time_frame)

    return results_to_html(signals)


@app.route('/pairs_trading',methods=['GET', 'POST'])
def pairs_trading():
    if request.method == 'POST':
        selected_pair = request.form.get('selectedPair')
        stock1, stock2 = selected_pair.replace(" ", "").split(",")
        tickers = [f"{stock1}", f"{stock2}"]
        print(tickers)
        data = get_historical_Data(tickers)

        stock1_data = data[f"{stock1}"]
        stock2_data = data[f"{stock2}"]

        ratio = stock1_data / stock2_data
        df_zscore = (ratio - ratio.mean()) / ratio.std()
        ratios_mavg5 = ratio.rolling(window=5, center=False).mean()
        ratios_mavg20 = ratio.rolling(window=20, center=False).mean()
        std_20 = ratio.rolling(window=20, center=False).std()
        zscore_20_5 = (ratios_mavg5 - ratios_mavg20) / std_20
        
        buy = ratio.copy()
        sell = ratio.copy()
        buy_signals = zscore_20_5 < -1
        sell_signals = zscore_20_5 > 1
        buy[~buy_signals] = np.nan
        sell[~sell_signals] = np.nan
        
        buy_prices_stock1 = stock1_data[buy_signals]
        buy_prices_stock2 = stock2_data[buy_signals]
        sell_prices_stock1 = stock1_data[sell_signals]
        sell_prices_stock2 = stock2_data[sell_signals]

        trades_df = pd.DataFrame({
            f'Buy {stock1}': buy_prices_stock1,
            f'Buy {stock2}': buy_prices_stock2,
            f'Sell {stock1}': sell_prices_stock1,
            f'Sell {stock2}': sell_prices_stock2
        })
        logs(trades_df)
        
        # Cumulative P&L Calculation for equal buys and sells
        if len(sell_prices_stock1)>len(buy_prices_stock1):
            length=len(buy_prices_stock1)
        else:
            length=len(sell_prices_stock1)
        matched_buy_prices_stock1 = buy_prices_stock1.dropna().iloc[:length]
        matched_sell_prices_stock1 = sell_prices_stock1.dropna().iloc[:length]
        
        matched_buy_prices_stock2 = buy_prices_stock2.dropna().iloc[:length]
        matched_sell_prices_stock2 = sell_prices_stock2.dropna().iloc[:length]

        matched_pnl = ((matched_sell_prices_stock1.values - matched_buy_prices_stock1.values) + 
                       (matched_sell_prices_stock2.values - matched_buy_prices_stock2.values)).sum()
        
        # Squaring off remaining positions at the end
        final_price_stock1 = stock1_data.iloc[-1]
        final_price_stock2 = stock2_data.iloc[-1]

        remaining_buy_prices_stock1 = buy_prices_stock1.dropna().iloc[length:]
        remaining_sell_prices_stock1 = sell_prices_stock1.dropna().iloc[length:]

        remaining_buy_prices_stock2 = buy_prices_stock2.dropna().iloc[length:]
        remaining_sell_prices_stock2 = sell_prices_stock2.dropna().iloc[length:]

        remaining_pnl = (
            (final_price_stock1 - remaining_buy_prices_stock1).sum() +
            (remaining_sell_prices_stock1 - final_price_stock1).sum() +
            (remaining_buy_prices_stock2 - final_price_stock2).sum() +
            (final_price_stock2 - remaining_sell_prices_stock2).sum()
        )

        total_pnl = matched_pnl + remaining_pnl

        # Write to Excel
        trades_df['Total P&L'] = total_pnl
        
        trades_df.to_excel('pairs_trading_results.xlsx', index=False)
        
        figure(figsize=(8, 6), dpi=200)
        ratio.plot()
        buy.plot(color='g', linestyle='None', marker='^', markersize=5)
        sell.plot(color='r', linestyle='None', marker='v', markersize=5)
        plt.legend(['Ratio', 'Buy Signal', 'Sell Signal'])
        plt.title(f'Relationship {stock1} to {stock2}')
        plt.show()

        return render_template('pairs_trading.html', name=tickers, total_pnl=total_pnl)
    
    nifty_50_data = get_historical_Data(nifty_50_tickers)
    corr_matrix = nifty_50_data.corr()
    high_corr_pairs = []

    for i in range(len(corr_matrix.columns)):
        for j in range(i + 1, len(corr_matrix.columns)):
            if corr_matrix.iloc[i, j] > abs(0.95):
                high_corr_pairs.append((corr_matrix.columns[i], corr_matrix.columns[j]))
    print("Error")
        
    return render_template('pairs_trading.html', name=high_corr_pairs)


# def results_to_html(signals):
#     html = '<h2>Backtest Results</h2>'
#     html += '<table border="1"><tr><th>Date</th><th>Signal</th><th>Price</th></tr>'
#     for signal in signals:
#         html += f'<tr><td>{signal[0]}</td><td>{signal[1]}</td><td>{signal[2]}</td></tr>'
#     html += '</table>'
#     return html

# @app.route('/backtest', methods=['POST'])
# def backtest():
#     strategy_name = request.form['strategy_name']
#     instrument_name = request.form['instrument_name']
#     start_date = request.form['start_date']
#     end_date = request.form['end_date']
#     time_frame = request.form['time_frame']
#     expiry = request.form['expiry']
#     strike = request.form['strike']
#     strike_length = request.form['strike_length']
#     option_type = request.form['option_type']
#     lot_size = request.form['lot_size']
#     spread = request.form['spread']
#     exit_spread = request.form['exit_spread']
#     action = request.form['action']
    
#     data = {
#         'strategy_name': strategy_name,
#         'instrument_name': instrument_name,
#         'start_date': start_date,
#         'end_date': end_date,
#         'time_frame': time_frame,
#         'expiry': expiry,
#         'strike': strike,
#         'strike_length': strike_length,
#         'option_type': option_type,
#         'lot_size': lot_size,
#         'spread': spread,
#         'exit_spread': exit_spread,
#         'action': action
#     }
    
#     save_data_to_db(data)
#     return data

def backtest_golden_cross(ticker, start_date, end_date, short_window, long_window, profit_target, stop_loss, time_frame):

    data = yf.download(ticker, start=start_date, end=end_date, interval=time_frame)

    data['SMA50'] = data['Close'].rolling(window=short_window).mean()
    data['SMA200'] = data['Close'].rolling(window=long_window).mean()
    data['Signal'] = 0
    data['Position'] = 0
    data['Buy Price'] = np.nan
    data['Sell Price'] = np.nan

    current_position = 0
    entry_price = 0
    target_price = 0
    stop_price = 0

    signals = []

    for i in range(len(data)):
        if current_position == 0:
            if data['SMA50'].iloc[i] > data['SMA200'].iloc[i]:
                current_position = 1  # Enter long position
                entry_price = data['Close'].iloc[i]
                target_price = entry_price * (1 + profit_target)
                stop_price = entry_price * (1 - stop_loss)
                data.at[data.index[i], 'Signal'] = 1
                data.at[data.index[i], 'Buy Price'] = entry_price
                signals.append((data.index[i], 'BUY', entry_price))
            elif data['SMA50'].iloc[i] < data['SMA200'].iloc[i]:
                current_position = -1  # Enter short position
                entry_price = data['Close'].iloc[i]
                target_price = entry_price * (1 - profit_target)
                stop_price = entry_price * (1 + stop_loss)
                data.at[data.index[i], 'Signal'] = -1
                data.at[data.index[i], 'Sell Price'] = entry_price
                signals.append((data.index[i], 'SELL', entry_price))
        elif current_position == 1:
            if data['Close'].iloc[i] >= target_price or data['Close'].iloc[i] <= stop_price:
                current_position = 0  # Exit long position
                data.at[data.index[i], 'Signal'] = -1
                data.at[data.index[i], 'Sell Price'] = data['Close'].iloc[i]
                signals.append((data.index[i], 'SELL', data['Close'].iloc[i]))
        elif current_position == -1:
            if data['Close'].iloc[i] <= target_price or data['Close'].iloc[i] >= stop_price:
                current_position = 0  # Exit short position
                data.at[data.index[i], 'Signal'] = 1
                data.at[data.index[i], 'Buy Price'] = data['Close'].iloc[i]
                signals.append((data.index[i], 'BUY', data['Close'].iloc[i]))
    
    # total_return = data['Cumulative Strategy Return'].iloc[-1]
    # annual_return = (1 + total_return) ** (252 / len(data)) - 1  # Assuming 252 trading days per year
    # print(f'Total Return: {total_return:.2f}')
    # print(f'Annualized Return: {annual_return:.2f}')

    return signals

def results_to_html(signals):
    if not signals:
        return '<h2>No signals were generated during the backtest period.</h2>'
    html = '<h2>Backtest Results</h2>'
    html += '<table border="1"><tr><th>Date</th><th>Signal</th><th>Price</th></tr>'
    for signal in signals:
        html += f'<tr><td>{signal[0]}</td><td>{signal[1]}</td><td>{signal[2]}</td></tr>'
    html += '</table>'
    return html

@app.route('/golden_cross_backtest', methods=['POST'])
def backtest():
    ticker = request.form['ticker']
    start_date = request.form['start_date']
    end_date = request.form['end_date']
    short_window = int(request.form['short_window'])
    long_window = int(request.form['long_window'])
    profit_target = float(request.form['profit_target'])
    stop_loss = float(request.form['stop_loss'])
    time_frame = request.form['time_frame']

    signals = backtest_golden_cross(ticker, start_date, end_date, short_window, long_window, profit_target, stop_loss, time_frame)

    return results_to_html(signals)

@app.route('/mean_reversion', methods=['GET', 'POST'])
def golden():
    return render_template('golden_cross.html')

@app.route('/rsi_strategy', methods=['GET', 'POST'])
def rsi():
    return render_template('rsi_strategy.html')

@app.route('/bearish_engulfing_show', methods=['GET', 'POST'])
def bearish():
    return render_template('bearish_engulfing.html')

@app.route('/bearish_engulfing', methods=['POST'])
def bearish_engulfing():
    try:
        # Get the CSV file from the request
        file = request.files['/Users/yashedake/Desktop/Projects/backtesting/intraday_5min_AAPL.csv']
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')
        target_profit = float(request.form.get('target_profit', 0.2))
        stop_loss = float(request.form.get('stop_loss', 0.1))

        # Read the CSV file into a DataFrame
        df = pd.read_csv(file, parse_dates=['timestamp'])

        # Call the bearish_engulfing_strategy function
        signals = bearish_engulfing_strategy(df, start_date=start_date, end_date=end_date, target_profit=target_profit, stop_loss=stop_loss)

        # Convert the DataFrame to JSON
        signals_json = signals.to_json(orient='records', date_format='iso')

        return jsonify({'signals': signals_json})
    except Exception as e:
        return jsonify({'error': str(e)}), 500



if __name__ == '__main__':
    app.run(port=8000,debug=True)