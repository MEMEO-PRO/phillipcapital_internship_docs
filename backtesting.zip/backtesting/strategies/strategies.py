import json
import logging
import pandas as pd
from flask import Flask, render_template

logging.basicConfig(filename='iron_condor_strategy.log', level=logging.INFO, format='%(asctime)s - %(message)s')

def short_straddle_strategy(option_data, current_price):
    data = json.loads(option_data)

    underlying_price = data['underlying_price']
    strike_price = data['strike_price']
    expiration_date = data['expiration_date']
    volatility = data['volatility']

    upper_breakeven = strike_price + volatility * underlying_price
    lower_breakeven = strike_price - volatility * underlying_price

    if current_price > upper_breakeven:
        decision = "Sell"
    elif current_price < lower_breakeven:
        decision = "Buy"
    else:
        decision = "Hold"

    return decision


def short_strangle_strategy(option_data, current_price):
    data = json.loads(option_data)
    underlying_price = data['underlying_price']
    strike_price = data['strike_price']
    expiration_date = data['expiration_date']
    volatility = data['volatility']
    upper_breakeven = strike_price + volatility * underlying_price
    lower_breakeven = strike_price - volatility * underlying_price
    if current_price > upper_breakeven:
        decision = "Sell"
    elif current_price < lower_breakeven:
        decision = "Buy"
    else:
        decision = "Hold"
    return decision

def ratio_spread_strategy(option_data, current_price):

    data = json.loads(option_data)

    underlying_price = data['underlying_price']
    strike_price = data['strike_price']
    expiration_date = data['expiration_date']
    volatility = data['volatility']
    supertrend = calculate_supertrend(data) 

    upper_breakeven = strike_price + (volatility * underlying_price)
    lower_breakeven = strike_price - (volatility * underlying_price)

    if current_price > upper_breakeven and supertrend == "Up":
        decision = "Sell"
    elif current_price < lower_breakeven and supertrend == "Down":
        decision = "Buy"
    else:
        decision = "Hold"

    return decision

def calculate_supertrend(data):
    #yet to implemnet
    pass





def iron_condor_intraday_strategy(intraday_data, option_data, stop_loss_percentage):
    
    data = pd.read_csv(intraday_data, parse_dates=['Timestamp'])
    option = json.loads(option_data)
    
    underlying_price = option['underlying_price']
    lower_strike_put = option['lower_strike_put']
    higher_strike_put = option['higher_strike_put']
    lower_strike_call = option['lower_strike_call']
    higher_strike_call = option['higher_strike_call']
    premium_lower_put = option['premium_lower_put']
    premium_higher_put = option['premium_higher_put']
    premium_lower_call = option['premium_lower_call']
    premium_higher_call = option['premium_higher_call']
    expiration_date = option['expiration_date']
    stop_loss_amount = option['stop_loss']
    profit_amount = option['book_profit']

    total_premium_received = (premium_lower_call - premium_higher_call) + (premium_higher_put - premium_lower_put)
    width_put_spread = higher_strike_put - lower_strike_put
    width_call_spread = higher_strike_call - lower_strike_call

    position = 0
    buy_price = None
    total_pnl = 0
    sell_decision_logged = False

    log_msg = f"Lower Strike Put: {lower_strike_put}, Higher Strike Put: {higher_strike_put}, "
    log_msg += f"Lower Strike Call: {lower_strike_call}, Higher Strike Call: {higher_strike_call}, "
    log_msg += f"Premiums - Lower Put: {premium_lower_put}, Higher Put: {premium_higher_put}, "
    log_msg += f"Lower Call: {premium_lower_call}, Higher Call: {premium_higher_call}"
    logging.info(log_msg)

    for index, row in data.iterrows():
        current_time = row['Timestamp'].time()
        
        if position == 0:
            buy_price = premium_lower_put - premium_higher_put + premium_lower_call - premium_higher_call
            position = 1
            log_msg = f"Buy at {buy_price} on {row['Timestamp']}"
            print(log_msg)
            logging.info(log_msg)

        current_premium = (premium_lower_call - premium_higher_call) + (premium_higher_put - premium_lower_put)
        current_profit_loss = current_premium - total_premium_received
        
        if buy_price is not None:
            if current_profit_loss <= -stop_loss_amount:
                sell_price = premium_lower_put - premium_higher_put + premium_lower_call - premium_higher_call
                pnl = (sell_price - buy_price) * position
                total_pnl += pnl
                position = 0
                log_msg = f"Stop loss triggered. Sell at {sell_price} on {row['Timestamp']}. PnL: {pnl}"
                print(log_msg)
                logging.info(log_msg)
                sell_decision_logged = True
                continue
            elif current_profit_loss >= profit_amount:
                sell_price = premium_lower_put - premium_higher_put + premium_lower_call - premium_higher_call
                pnl = (sell_price - buy_price) * position
                total_pnl += pnl
                position = 0
                log_msg = f"Profit booking triggered. Sell at {sell_price} on {row['Timestamp']}. PnL: {pnl}"
                print(log_msg)
                logging.info(log_msg)
                sell_decision_logged = True
                continue
        
        if current_time >= pd.to_datetime('15:59:00').time():
            if position > 0:
                sell_price = premium_lower_put - premium_higher_put + premium_lower_call - premium_higher_call
                pnl = (sell_price - buy_price) * position
                total_pnl += pnl
                position = 0
                log_msg = f"Square off at {sell_price} on {row['Timestamp']}. PnL: {pnl}"
                print(log_msg)
                logging.info(log_msg)
                sell_decision_logged = True
    
    if not sell_decision_logged and position > 0:
        final_price = premium_lower_put - premium_higher_put + premium_lower_call - premium_higher_call
        pnl = (final_price - buy_price) * position
        total_pnl += pnl
        log_msg = f"Final position squared off at {final_price}. PnL: {pnl}"
        print(log_msg)
        logging.info(log_msg)
    
    log_msg = f"Final PnL: {total_pnl}"
    print(log_msg)
    logging.info(log_msg)
    
    return total_pnl

import json


def short_long_bull(option_data, current_price):
    data = json.loads(option_data)
    
    strike_price_long = data['strike_price_long']  
    strike_price_short = data['strike_price_short']  
    premium_long = data['premium_long']  
    premium_short = data['premium_short']  
    expiration_date = data['expiration_date']  
    
    max_profit = (strike_price_short - strike_price_long) - (premium_long - premium_short)
    max_loss = premium_long - premium_short
    
    if current_price >= strike_price_short:
        decision = "Maximum Profit (Bull Call Spread Achieved)"
    elif current_price <= strike_price_long:
        decision = "Maximum Loss (Long Call Expires Worthless)"
    else:
        decision = "Potential Profit (Between Strikes)"
    
    return {
        "decision": decision,
        "max_profit": max_profit,
        "max_loss": max_loss
    }


def Long_Short_Bull(option_data, current_price):
    data = json.loads(option_data)
    
    strike_price_long = data['strike_price_long']  
    strike_price_short = data['strike_price_short']  
    premium_long = data['premium_long']  
    premium_short = data['premium_short']  
    expiration_date = data['expiration_date']  
    
    max_profit = (strike_price_short - strike_price_long - premium_long + premium_short)
    max_loss = premium_long - premium_short
    
    if current_price < strike_price_short:
        decision = "Maximum Profit (Bear Put Spread Achieved)"
    elif current_price > strike_price_long:
        decision = "Maximum Loss (Long Put Expires Worthless)"
    else:
        decision = "Potential Profit (Between Strikes)"
    
    return {
        "decision": decision,
        "max_profit": max_profit,
        "max_loss": max_loss
    }

def bear_call_spread(option_data, current_price):
    data = json.loads(option_data)
    
    strike_price_short = data['strike_price_short']  
    strike_price_long = data['strike_price_long']   
    premium_short = data['premium_short']           
    premium_long = data['premium_long']             
    expiration_date = data['expiration_date']        
    
    max_profit = premium_short
    max_loss = (strike_price_long - strike_price_short - premium_short + premium_long)
    
    if current_price < strike_price_short:
        decision = "Maximum Profit (Bear Call Spread Achieved)"
    elif current_price > strike_price_long:
        decision = "Maximum Loss (Long Call Exercise Risk)"
    else:
        decision = "Potential Profit (Between Strikes)"
    
    return {
        "decision": decision,
        "max_profit": max_profit,
        "max_loss": max_loss
    }

def bullish_put_strategy(option_data, current_price):
    data = json.loads(option_data)
    
    strike_price_long = data['strike_price_long']  
    strike_price_short = data['strike_price_short']  
    premium_long = data['premium_long']  
    premium_short = data['premium_short']  
    expiration_date = data['expiration_date']  
    
    max_profit = (strike_price_short - strike_price_long - premium_long + premium_short)
    max_loss = premium_long - premium_short
    
    logs = []  # List to store logs

    if current_price > strike_price_short:
        decision = "Maximum Profit (Long Put Spread Achieved)"
        logs.append(f"Current price {current_price} is above short strike price {strike_price_short}. Decision: {decision}")
    elif current_price < strike_price_long:
        decision = "Maximum Loss (Short Put Exercise Risk)"
        logs.append(f"Current price {current_price} is below long strike price {strike_price_long}. Decision: {decision}")
    else:
        decision = "Potential Profit (Between Strikes)"
        logs.append(f"Current price {current_price} is between long strike price {strike_price_long} and short strike price {strike_price_short}. Decision: {decision}")

    logs.append(f"Max Profit: {max_profit}")
    logs.append(f"Max Loss: {max_loss}")
    
    logs_df = pd.DataFrame({'Log': logs})
    
    excel_filename = 'bullish_put_logs.xlsx'
    logs_df.to_excel(excel_filename, index=False)
    
    print(f"Logs saved to {excel_filename}")

    return {
        "decision": decision,
        "max_profit": max_profit,
        "max_loss": max_loss
    }

def long_short_call(option_data, current_price):
    data = json.loads(option_data)
    
    strike_price_long = data['strike_price_long'] 
    strike_price_short = data['strike_price_short']  
    quantity_long = data['quantity_long']  
    quantity_short = data['quantity_short']  
    premium_long = data['premium_long']  
    premium_short = data['premium_short']  
    expiration_date = data['expiration_date']  
    
    max_profit = quantity_long * (strike_price_short - strike_price_long) - quantity_long * premium_long + quantity_short * premium_short
    max_loss = quantity_long * premium_long - quantity_short * premium_short
    
    logs = [] 

    if current_price > strike_price_short:
        decision = "Maximum Profit (Ratio Call Spread Achieved)"
        logs.append(f"Current price {current_price} is above short strike price {strike_price_short}. Decision: {decision}")
    elif current_price < strike_price_long:
        decision = "Maximum Loss (Long Call Options Expire Worthless)"
        logs.append(f"Current price {current_price} is below long strike price {strike_price_long}. Decision: {decision}")
    else:
        decision = "Potential Profit (Between Strikes)"
        logs.append(f"Current price {current_price} is between long strike price {strike_price_long} and short strike price {strike_price_short}. Decision: {decision}")

    logs.append(f"Max Profit: {max_profit}")
    logs.append(f"Max Loss: {max_loss}")
    
    logs_df = pd.DataFrame({'Log': logs})
    
    excel_filename = 'long_short_call_logs.xlsx'
    logs_df.to_excel(excel_filename, index=False)
    
    print(f"Logs saved to {excel_filename}")

    return {
        "decision": decision,
        "max_profit": max_profit,
        "max_loss": max_loss
    }

def long_short_put(option_data, current_price):
    data = json.loads(option_data)
    
    strike_price_long = data['strike_price_long']  
    strike_price_short = data['strike_price_short']  
    premium_long = data['premium_long']  
    premium_short = data['premium_short']  
    expiration_date = data['expiration_date']  
    
    max_profit = (strike_price_short - strike_price_long - premium_long + premium_short)
    max_loss = premium_long - premium_short
    
    logs = [] 

    if current_price < strike_price_short:
        decision = "Maximum Profit (Long Put Spread Achieved)"
        logs.append(f"Current price {current_price} is below short strike price {strike_price_short}. Decision: {decision}")
    elif current_price > strike_price_long:
        decision = "Maximum Loss (Short Put Exercise Risk)"
        logs.append(f"Current price {current_price} is above long strike price {strike_price_long}. Decision: {decision}")
    else:
        decision = "Potential Profit (Between Strikes)"
        logs.append(f"Current price {current_price} is between long strike price {strike_price_long} and short strike price {strike_price_short}. Decision: {decision}")

    logs.append(f"Max Profit: {max_profit}")
    logs.append(f"Max Loss: {max_loss}")
    
    # Convert logs to DataFrame
    logs_df = pd.DataFrame({'Log': logs})
    
    # Save to Excel
    excel_filename = 'long_short_put_logs.xlsx'
    logs_df.to_excel(excel_filename, index=False)
    
    print(f"Logs saved to {excel_filename}")

    return {
        "decision": decision,
        "max_profit": max_profit,
        "max_loss": max_loss
    }

def long_call_intraday_strategy(data, option_data, stop_loss_percentage, profit_percentage):
    data = pd.DataFrame(data)
    option = json.loads(option_data)
    
    premium = option['premium']
    
    position = 0
    buy_price = 0
    total_pnl = 0
    
    data['Datetime'] = pd.to_datetime(data['Datetime'])
    data.set_index('Datetime', inplace=True)
    
    logs = [] 
    
    for index, row in data.iterrows():
        current_price = row['Close']
        current_time = index.time()
        
        if position == 0:
            position = 1
            buy_price = current_price + premium
            logs.append(f"Buy at {current_price} on {index}")
        
        if position == 1:
            if current_price < buy_price * (1 - stop_loss_percentage / 100):
                sell_price = current_price
                pnl = sell_price - buy_price
                total_pnl += pnl
                position = 0
                logs.append(f"Stop loss triggered. Sell at {sell_price} on {index}. PnL: {pnl}")
            
            elif current_price >= buy_price * (1 + profit_percentage / 100):
                sell_price = current_price
                pnl = sell_price - buy_price
                total_pnl += pnl
                position = 0
                logs.append(f"Profit target reached. Sell at {sell_price} on {index}. PnL: {pnl}")
            
            elif current_time >= pd.to_datetime('15:29:00').time():
                sell_price = current_price
                pnl = sell_price - buy_price
                total_pnl += pnl
                position = 0
                logs.append(f"Square off at {sell_price} on {index}. PnL: {pnl}")

    if position > 0:
        final_price = data.iloc[-1]['Close']
        pnl = final_price - buy_price
        total_pnl += pnl
        logs.append(f"Remaining position sold at {final_price} on {data.index[-1]}. PnL: {pnl}")

    logs.append(f"Final PnL: {total_pnl}")

    logs_df = pd.DataFrame({'Log': logs})
    
    excel_filename = 'long_call_intraday_logs.xlsx'
    logs_df.to_excel(excel_filename, index=False)
    
    print(f"Logs saved to {excel_filename}")
    print(f"Final PnL: {total_pnl}")
    return total_pnl




def bull_engulfing_strategy(data):
    total_shares = 0
    total_pnl = 0
    buy_price = 0
    stop_loss = 10
    book_profit = 20
    
    data['Signal'] = 0
    
    logs = [] 
    
    for i in range(1, len(data)):
        prev_open = data.loc[i-1, 'Open']
        prev_close = data.loc[i-1, 'Close']
        curr_open = data.loc[i, 'Open']
        curr_close = data.loc[i, 'Close']
        
        if prev_close < prev_open and curr_close > curr_open:
            if curr_open < prev_close and curr_close > prev_open:
                data.loc[i, 'Signal'] = 1
                logs.append(f"Buy signal detected at {data.loc[i, 'Datetime']}")
    
    for i in range(len(data)):
        time = pd.to_datetime(data.loc[i, 'Datetime']).time()
        
        if data.loc[i, 'Signal'] == 1 and total_shares == 0:
            buy_price = data.loc[i, 'Close']
            stop_loss_price = buy_price * (1 - stop_loss / 100)
            profit_price = buy_price * (1 + book_profit / 100)
            total_shares += 1  
            logs.append(f"Buy at {buy_price} on {data.loc[i, 'Datetime']}")
        
        if total_shares > 0:
            sell_price = data.loc[i, 'Close']
            
            if sell_price <= stop_loss_price:
                total_pnl += (sell_price - buy_price) * total_shares  
                total_shares = 0  
                logs.append(f"Sell (Stop Loss) at {sell_price} on {data.loc[i, 'Datetime']}")
            
            if sell_price >= profit_price:
                total_pnl += (sell_price - buy_price) * total_shares
                total_shares = 0  
                logs.append(f"Sell (Book Profit) at {sell_price} on {data.loc[i, 'Datetime']}")
            
            elif time >= pd.to_datetime('15:29:00').time():
                total_pnl += (sell_price - buy_price) * total_shares  
                total_shares = 0  
                logs.append(f"Sell (End of Day) at {sell_price} on {data.loc[i, 'Datetime']}")
    
    if total_shares > 0:
        final_price = data.loc[len(data) - 1, 'Close']
        total_pnl += (final_price - buy_price) * total_shares
        logs.append(f"Remaining position sold at {final_price} on {data.loc[len(data) - 1, 'Datetime']}")
    
    logs.append(f"Final PnL: {total_pnl}")
    
    logs_df = pd.DataFrame({'Log': logs})
    
    excel_filename = 'bull_engulfing_logs.xlsx'
    logs_df.to_excel(excel_filename, index=False)
    
    print(f"Logs saved to {excel_filename}")
    print(f"Final PnL: {total_pnl}")

# csv_file = 'C:\FE\Phillip_Backtesting\intraday_5min_AAPL (1).csv'
# data = pd.read_csv(csv_file)



# bull_engulfing_strategy( data)