import pandas as pd


def bearish_engulfing_strategy(data, start_date=None, end_date=None, target_profit=0.2, stop_loss=0.1):
    df = pd.read_csv(data, parse_dates=['timestamp'])
    df.sort_values('timestamp', inplace=True)
    df.reset_index(drop=True, inplace=True)
    
    # Filter data based on start_date and end_date
    if start_date:
        df = df[df['timestamp'] >= start_date]
    if end_date:
        df = df[df['timestamp'] <= end_date]
    
    def is_bearish_engulfing(prev_open, prev_close, curr_open, curr_close):
        return prev_close > prev_open and curr_open > prev_close and curr_close < prev_open
    
    df['Bearish_Engulfing'] = 0
    for i in range(1, len(df)):
        if is_bearish_engulfing(df.loc[i-1, 'open'], df.loc[i-1, 'close'], df.loc[i, 'open'], df.loc[i, 'close']):
            df.loc[i, 'Bearish_Engulfing'] = 1
    
    df['Signal'] = None
    df['Buy_Price'] = None
    df['Sell_Price'] = None
    logs = []
    
    for i in range(1, len(df)):
        if df.loc[i, 'Bearish_Engulfing'] == 1:
            df.loc[i, 'Signal'] = 'Sell'
            df.loc[i, 'Sell_Price'] = df.loc[i, 'close']
            logs.append(f"Sell Signal: {df.loc[i, 'timestamp']} at {df.loc[i, 'Sell_Price']}")
            stop_loss_price = df.loc[i, 'high'] + stop_loss
            target_price = df.loc[i, 'close'] - target_profit
            
            for j in range(i+1, len(df)):
                if df.loc[j, 'high'] > stop_loss_price or df.loc[j, 'low'] < target_price:
                    df.loc[j, 'Signal'] = 'Buy'
                    df.loc[j, 'Buy_Price'] = df.loc[j, 'close']
                    logs.append(f"Buy Signal: {df.loc[j, 'timestamp']} at {df.loc[j, 'Buy_Price']}")
                    break
    
    signals = df.dropna(subset=['Signal'])
    #print(signals[['timestamp', 'open', 'high', 'low', 'close', 'volume', 'Signal', 'Buy_Price', 'Sell_Price']])
    # for log in logs:
    #     print(log)
    return signals


# # Example usage:
# data_file = "/Users/yashedake/Desktop/Projects/backtesting/intraday_5min_AAPL.csv"
# start_date = '2024-01-01'  # Example start date (YYYY-MM-DD format)
# end_date = '2024-12-31'    # Example end date (YYYY-MM-DD format)
# target_profit = 0.2         # Example value for target profit
# stop_loss = 0.1             # Example value for stop loss

# bearish_engulfing_strategy(data_file, start_date=start_date, end_date=end_date, target_profit=target_profit, stop_loss=stop_loss)

