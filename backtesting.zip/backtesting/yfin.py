import requests
import pandas as pd
import time
from datetime import datetime, timedelta
import yfinance as yf

# URL and headers for the API request
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.53 Safari/537.36 Edg/103.0.1264.37',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en;q=0.9,en-US;q=0.8'
}


# start_date = datetime(2023, 6, 10)  
# end_date = datetime(2023, 9, 19)    

trading_start = datetime.strptime("09:30", "%H:%M").time()
trading_end = datetime.strptime("15:30", "%H:%M").time()

def fetch_data(url, headers, cookies, session):
    try:
        response = session.get(url, headers=headers, cookies=cookies)
        response.raise_for_status()  # Raise HTTPError for bad responses
        rawdata = response.json()
    except requests.exceptions.RequestException as e:
        print(f"Request error: {e}")
        return pd.DataFrame()
    except ValueError as e:
        print(f"JSON decode error: {e}")
        return pd.DataFrame()

    rawop = pd.DataFrame(rawdata['filtered']['data']).fillna(0)
    data = []
    for i in range(len(rawop)):
        calloi = callcoi = cltp = putoi = putcoi = pltp = 0
        stp = rawop['strikePrice'][i]
        if rawop['CE'][i] == 0:
            calloi = callcoi = 0
        else:
            calloi = rawop['CE'][i]['openInterest']
            callcoi = rawop['CE'][i]['changeinOpenInterest']
            cltp = rawop['CE'][i]['lastPrice']
        if rawop['PE'][i] == 0:
            putoi = putcoi = 0
        else:
            putoi = rawop['PE'][i]['openInterest']
            putcoi = rawop['PE'][i]['changeinOpenInterest']
            pltp = rawop['PE'][i]['lastPrice']
        opdata = {
            'CALL LTP': cltp, 'STRIKE PRICE': stp,
            'PUT LTP': pltp
        }
        data.append(opdata)
    optionchain = pd.DataFrame(data)
    return optionchain

def get_historical_data(start_date, end_date):
    tickers = '^NSEI'
    ticker_data = yf.download(tickers, start=start_date, end=end_date)
    ticker_data['Date'] = ticker_data.index.date
    return ticker_data[['Close', 'Date']]

def get_data(start_date, end_date, trading_start, trading_end, symbol, timeframe):
    url = f'https://www.nseindia.com/api/option-chain-indices?symbol={symbol}'
    session = requests.Session()
    request = session.get(url, headers=headers)
    cookies = dict(request.cookies)

    all_data = pd.DataFrame()
    current_time = start_date
    data = get_historical_data(start_date=start_date, end_date=end_date)
    #print(data)
    while current_time < end_date:
        if trading_start <= current_time.time() <= trading_end:
            optionchain = fetch_data(url, headers, cookies, session)
            if optionchain.empty:
                continue
            optionchain['DATE'] = current_time.date()  # Use date only for merging
            all_data = pd.concat([all_data, optionchain])
        current_time += timedelta(minutes=timeframe)

    # Merge the dataframes on the 'Date' column manually
    all_data['DATE'] = pd.to_datetime(all_data['DATE']).dt.date
    data['Date'] = pd.to_datetime(data['Date']).dt.date

    all_data['Close'] = all_data['DATE'].map(data.set_index('Date')['Close'])

    return all_data

# Example usage
# if __name__ == "__main__":
    # data = get_data(start_date, end_date, trading_start, trading_end, 'NIFTY', timeframe=360)
    # print(data)
    # data.to_csv('nifty_data.csv', index=False)
