# import schedule
import datetime
from nsetools import Nse
import pandas as pd

def csv_to_array(csv_file_path):
    df = pd.read_csv(csv_file_path)
    return df.values.tolist()

csv_file_path = 'C:\\FE\\Phillip_Backtesting\\alldata.csv'
data = csv_to_array(csv_file_path)
print(data)

nse = Nse()
lot_size=nse.get_fno_lot_sizes()

data1={
    "strike": 1000,
    "option_type": "CE",
    "expiry": "2023-06-29",
    "premium": 100
}

data2={
    "strike": 1000,
    "option_type": "CE",
    "expiry": "2023-06-29",
    "premium": 200
}

selected_instrument_list = []
in_position_instrument_list = []
bought_instrument_logs = {}
sell_instrument_logs = {}

atm=[]

class check_order:
    def __init__(self, strategy_name, instrument_name, start_date, end_date, time_frame, 
                 expiry, strike, strike_length, option_type, lot_size, spread,
                  exit_spread, action):
        self.strategy_name = strategy_name
        self.instrument_name = instrument_name
        self.start_date = start_date
        self.end_date = end_date
        self.time_frame = time_frame
        self.expiry = expiry
        self.strike = strike
        self.strike_length = strike_length
        self.option_type = option_type
        self.lot_size = lot_size
        self.spread = spread
        self.exit_spread = exit_spread
        self.action = action

    def entry_logic(self):
        pass

    def exit_logic(self):
        pass

    def entry_order(self):
        in_position_instrument_list.append(self.instrument_name)
        bought_instrument_logs.append({"instrument_name": self.instrument_name, 
                                       "entry_time": datetime.now(),
                                       "strike": self.strike,
                                       "option_type": self.option_type,
                                       "expiry": self.expiry,
                                       "lot_size": self.lot_size,
                                       "action": self.action,
                                       "entry_price": 0})
        print(f"Entry order for {self.instrument_name} is placed @ {datetime.now()}")
        return in_position_instrument_list, bought_instrument_logs

    def exit_order(self):
        if in_position_instrument_list:
            in_position_instrument_list.remove(self.instrument_name)
            sell_instrument_logs.remove({"instrument_name": self.instrument_name, 
                                       "entry_time": datetime.now(),
                                       "strike": self.strike,
                                       "option_type": self.option_type,
                                       "expiry": self.expiry,
                                       "lot_size": self.lot_size,
                                       "action": self.action,
                                       "entry_price": 0})
            print(f"Exit order for {self.instrument_name} is placed @ {datetime.now()}")
        return in_position_instrument_list
           

class strategy:
    def __init__(self, strategy_name, instrument_name, start_date, end_date, time_frame,
                 expiry , strike, strike_length, option_type, lot_size,spread,
                   exit_spread, action):
        self.strategy_name = strategy_name
        self.instrument_name = instrument_name
        self.start_date = start_date
        self.end_date = end_date
        self.time_frame = time_frame
        self.expiry = expiry
        self.strike = strike
        self.strike_length = strike_length
        self.option_type = option_type
        self.lot_size = lot_size
        self.spread = spread
        self.exit_spread = exit_spread
        self.action = action
        
    def bear_bull_spread(self):
        if data1["premium"] + data2["premium"] == self.spread: #condition
            if self.action == "Buy":
                check_order.entry_order()
            elif self.action == "Sell":
                check_order.exit_order()

        if data1["premium"] + data2["premium"] >= self.exit_spread:
            if self.action == "Buy":
                check_order.exit_order()
            elif self.action == "Sell":
                check_order.entry_order()
        
    def bull_call_spread(self):
        pass
        if True: 
            check_order.entry_order()
        else:
            check_order.exit_order()

        





def loop():
    check_order.exit_logic()
    check_order.exit_order()
    check_order.entry_logic()
    check_order.entry_order()
    strategy.bear_bull_spread()

def main():
    start_time = "09:15"
    end_time = "15:30"
    schedule.every(1).minutes.at(start_time).do(loop())

    